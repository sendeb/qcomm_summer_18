## Installation

This zip contains the following directory structure:

images/
info/
parse.py

The python 3 script parse.py reads in images from the image/ directory and corresponding facial point markers stored in the info/ directory, and draws the markers onto the images before writing them to a new out/ directory.

### Requirements for installation:
>> python 3.5 or higher (Anaconda is a great distribution that contains most of the libraries you need)
>> numpy
>> frameio (instructions below)

To run the script, you need to install my python package frameio, which is used to read/write images and draw points and boxes. I use my own library because its lightweight and easier to install than most image manipulation packages for python, but you can use something else if you want.

### To install frameio:

```
sudo apt-get install ffmpeg
https://github.com/abapst/frame_io
cd frame_io
./build.sh
```

You should (hopefully) now be able to run the parse script:

```
python parse.py
```
Let me know if there are any questions/problems with this part.

### Guide to point notation in the faceInfo files:

ID: Not used
LT: Top-left corner of bounding box
RT: Top-right corner of bounding box
LB: Bottom-left corner of bounding box
RB: Bottom-right corner of bounding box
LE: left eye center
RE: right eye center
LEIC: left eye inner corner
LEOC: left eye outer corner
REIC: right eye inner corner
REOC: right eye outer corner
ML: mouth left
MR: mouth right
NL: left nostril
NR: right nostril
MU: center of upper lip
