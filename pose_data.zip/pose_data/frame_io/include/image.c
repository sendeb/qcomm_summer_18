#ifndef IMAGE_H
#define IMAGE_H

void image_alloc(rgb *image, int h, int w, int c);

#endif
