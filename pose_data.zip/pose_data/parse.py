import numpy as np
import frameio as fio
import os, shutil

def read_info(filename):
    f= open(filename,'r')
    data = dict()
    for line in f:
        tmp = line.split(':')
        key = tmp[0]
        if key == 'ID':
            continue
        val = tmp[1]
        if val[-1] == '\n':
            val = val[:-1]
        val = tuple([int(i) for i in val[1:-1].split(',')])
        data[key] = val
    return data

def draw_markers(im, data):
    for key in data:
        im = fio.draw_marker(im,(data[key][0],data[key][1]),(255,0,0),6)
    return im

def parse_face_info(out_dir):
    image_dir = 'images'
    info_dir = 'info'
    image_list = list(zip(np.sort(os.listdir(image_dir)),
                          np.sort(os.listdir(info_dir))))

    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    os.mkdir(out_dir)

    im_height = 1280
    im_width = 768
    n_images = len(image_list)

    for n,f in enumerate(image_list):
        print('Processing image {}/{}'.format(n+1,n_images))
        im = fio.imread(image_dir+'/'+f[0])
        data = read_info(info_dir+'/'+f[1])
        im = draw_markers(im, data)
        fio.imwrite(im, out_dir+'/'+f[0].split('.')[0]+'.jpg')

if __name__ == "__main__":
    out_dir = 'out'
    parse_face_info(out_dir)
